# javaprintf
Just another implementation of printf (c/php-like) and print (Python-like) in java
